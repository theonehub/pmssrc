import React, { useState, useCallback } from 'react';
import ReactFlow, {
  Node,
  Edge,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  addEdge,
  Connection,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { Box, Paper, Typography } from '@mui/material';
import SalaryComponentNode from './SalaryComponentNode';
import FormulaNode from './FormulaNode';

// Register custom nodes
const nodeTypes = {
  salaryComponent: SalaryComponentNode,
  formula: FormulaNode,
};

interface SalaryComponent {
  id: string;
  name: string;
  value: number;
  formula?: string;
}

const FormulaBuilder: React.FC = () => {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [components, setComponents] = useState<SalaryComponent[]>([
    { id: '1', name: 'Basic Salary', value: 0 },
    { id: '2', name: 'HRA', value: 0 },
    { id: '3', name: 'Special Allowance', value: 0 },
  ]);

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  const onDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event: React.DragEvent) => {
      event.preventDefault();

      const type = event.dataTransfer.getData('application/reactflow');
      const name = event.dataTransfer.getData('name');

      if (!type) return;

      const position = {
        x: event.clientX - event.currentTarget.getBoundingClientRect().left,
        y: event.clientY - event.currentTarget.getBoundingClientRect().top,
      };

      const newNode: Node = {
        id: Math.random().toString(),
        type,
        position,
        data: { name },
      };

      setNodes((nds) => nds.concat(newNode));
    },
    [setNodes]
  );

  return (
    <Box sx={{ height: '100vh', display: 'flex' }}>
      <Paper
        sx={{
          width: '250px',
          p: 2,
          display: 'flex',
          flexDirection: 'column',
          gap: 2,
        }}
      >
        <Typography variant="h6">Salary Components</Typography>
        {components.map((component) => (
          <Box
            key={component.id}
            draggable
            onDragStart={(event) => {
              event.dataTransfer.setData('application/reactflow', 'salaryComponent');
              event.dataTransfer.setData('name', component.name);
            }}
            sx={{
              p: 2,
              border: '1px solid #ccc',
              borderRadius: 1,
              cursor: 'grab',
              '&:hover': {
                backgroundColor: '#f5f5f5',
              },
            }}
          >
            {component.name}
          </Box>
        ))}
      </Paper>
      <Box sx={{ flexGrow: 1 }}>
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          onDrop={onDrop}
          onDragOver={onDragOver}
          nodeTypes={nodeTypes}
          fitView
        >
          <Background />
          <Controls />
        </ReactFlow>
      </Box>
    </Box>
  );
};

export default FormulaBuilder; 