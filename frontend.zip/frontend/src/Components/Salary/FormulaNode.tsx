import React, { memo, useState } from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import {
  Paper,
  Typography,
  TextField,
  Box,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from '@mui/material';

interface FormulaData {
  name: string;
  formula: string;
}

const operators = [
  { value: '+', label: 'Add' },
  { value: '-', label: 'Subtract' },
  { value: '*', label: 'Multiply' },
  { value: '/', label: 'Divide' },
  { value: '%', label: 'Percentage' },
];

const FormulaNode: React.FC<NodeProps<FormulaData>> = memo(({ data }) => {
  const [selectedOperator, setSelectedOperator] = useState('+');
  const [condition, setCondition] = useState('');

  return (
    <Paper
      sx={{
        padding: 2,
        minWidth: 250,
        backgroundColor: '#f8f9fa',
        border: '1px solid #dee2e6',
      }}
    >
      <Handle type="target" position={Position.Top} />
      <Typography variant="subtitle1" gutterBottom>
        Formula Editor
      </Typography>
      
      <Box sx={{ mt: 2 }}>
        <FormControl fullWidth size="small" sx={{ mb: 2 }}>
          <InputLabel>Operator</InputLabel>
          <Select
            value={selectedOperator}
            label="Operator"
            onChange={(e) => setSelectedOperator(e.target.value)}
          >
            {operators.map((op) => (
              <MenuItem key={op.value} value={op.value}>
                {op.label}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <TextField
          size="small"
          label="Condition (optional)"
          placeholder="e.g., Basic > 0"
          value={condition}
          onChange={(e) => setCondition(e.target.value)}
          fullWidth
          sx={{ mb: 2 }}
        />

        <TextField
          size="small"
          label="Formula Preview"
          value={data.formula || ''}
          fullWidth
          multiline
          rows={2}
          InputProps={{
            readOnly: true,
          }}
        />
      </Box>

      <Handle type="source" position={Position.Bottom} />
    </Paper>
  );
});

export default FormulaNode; 