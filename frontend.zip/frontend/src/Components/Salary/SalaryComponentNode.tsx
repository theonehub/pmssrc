import React, { memo } from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { Paper, Typography, TextField } from '@mui/material';

interface SalaryComponentData {
  name: string;
  value?: number;
  formula?: string;
}

const SalaryComponentNode: React.FC<NodeProps<SalaryComponentData>> = memo(({ data }) => {
  return (
    <Paper
      sx={{
        padding: 2,
        minWidth: 200,
        backgroundColor: '#fff',
        border: '1px solid #ccc',
      }}
    >
      <Handle type="target" position={Position.Top} />
      <Typography variant="subtitle1" gutterBottom>
        {data.name}
      </Typography>
      <TextField
        size="small"
        label="Value"
        type="number"
        defaultValue={data.value || 0}
        fullWidth
        sx={{ mt: 1 }}
      />
      {data.formula && (
        <Typography variant="caption" sx={{ mt: 1, display: 'block' }}>
          Formula: {data.formula}
        </Typography>
      )}
      <Handle type="source" position={Position.Bottom} />
    </Paper>
  );
});

export default SalaryComponentNode; 