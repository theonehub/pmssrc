import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { getToken } from '../../utils/auth';
import { FaEdit, FaTrash, FaPlus } from 'react-icons/fa';
import PageLayout from '../../layout/PageLayout';
import { 
  Paper, 
  Button, 
  Container, 
  Table, 
  CircularProgress, 
  Alert, 
  TableContainer, 
  TableHead, 
  TableBody, 
  TableRow, 
  TableCell, 
  Box, 
  TextField, 
  Typography,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Snackbar,
  FormControlLabel,
  Checkbox
} from '@mui/material';

function SalaryComponents() {
  const [components, setComponents] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ name: '', type: 'earning', description: '' });
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [toast, setToast] = useState({ show: false, message: '', severity: 'success' });

  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 5;

  // Fetch components from API
  const fetchComponents = async () => {
    setLoading(true);
    try {
      const res = await axios.get('http://localhost:8000/salary-components', {
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      setComponents(res.data);
    } catch (error) {
      console.error('Error fetching components:', error);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchComponents();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      setToast({ show: true, message: 'Component name is required.', severity: 'error' });
      return;
    }

    try {
      if (editingId) {
        await axios.put(`http://localhost:8000/salary-components/${editingId}`, formData, {
          headers: { Authorization: `Bearer ${getToken()}` },
        });
        setToast({ show: true, message: 'Component updated successfully.', severity: 'success' });
      } else {
        await axios.post('http://localhost:8000/salary-components', formData, {
          headers: { Authorization: `Bearer ${getToken()}` },
        });
        setToast({ show: true, message: 'Component added successfully.', severity: 'success' });
      }
      fetchComponents();
      handleCloseForm();
    } catch (err) {
      console.error('Error saving component:', err);
      setToast({ show: true, message: 'Error saving component.', severity: 'error' });
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this component?')) return;

    try {
      await axios.delete(`http://localhost:8000/salary-components/${id}`, {
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      setToast({ show: true, message: 'Component deleted.', severity: 'info' });
      fetchComponents();
    } catch (err) {
      console.error('Error deleting component:', err);
      setToast({ show: true, message: 'Error deleting component.', severity: 'error' });
    }
  };

  const handleEdit = (comp) => {
    setFormData({ name: comp.name, type: comp.type, formula: comp.formula, is_active: comp.is_active, description: comp.description });
    setEditingId(comp.sc_id);
    setShowForm(true);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setFormData({ name: '', type: 'earning', formula: '', is_active: true, description: '' });
    setEditingId(null);
  };

  const filteredComponents = components.filter((comp) =>
    comp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    comp.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
    comp.formula.toLowerCase().includes(searchTerm.toLowerCase()) ||
    comp.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalPages = Math.ceil(filteredComponents.length / pageSize);
  const paginatedComponents = filteredComponents.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  return (
    <PageLayout>
      <div className="container mt-4">
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          <Typography variant="h4">Salary Components</Typography>
          <Button variant="contained" startIcon={<FaPlus />} onClick={() => setShowForm(true)}>
            Add Component
          </Button>
        </Box>

        <TextField
          fullWidth
          variant="outlined"
          placeholder="Search by name or type"
          size="small"
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setCurrentPage(1);
          }}
          sx={{ mb: 3 }}
        />

        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow sx={{ 
                '& .MuiTableCell-head': { 
                  backgroundColor: 'primary.main',
                  color: 'white',
                  fontWeight: 'bold',
                  fontSize: '0.875rem',
                  padding: '12px 16px'
                }
              }}>
                <TableCell>Component Name</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Formula</TableCell>
                <TableCell>Is Active</TableCell>
                <TableCell>Description</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={5} align="center">Loading...</TableCell>
                </TableRow>
              ) : components.length > 0 ? (
                components.map((component) => (
                  <TableRow 
                    key={component.id}
                    sx={{ 
                      '&:hover': { 
                        backgroundColor: 'action.hover',
                        cursor: 'pointer'
                      }
                    }}
                  >
                    <TableCell>{component.name}</TableCell>
                    <TableCell>{component.type}</TableCell>
                    <TableCell>{component.formula}</TableCell>
                    <TableCell>{component.is_active ? 'Yes' : 'No'}</TableCell>
                    <TableCell>{component.description}</TableCell>
                    
                    <TableCell>
                      <Box sx={{ display: 'flex', gap: 1 }}>
                        <Button
                          variant="contained"
                          color="primary"
                          size="small"
                          onClick={() => handleEdit(component)}
                        >
                          Edit
                        </Button>
                        <Button
                          variant="contained"
                          color="error"
                          size="small"
                          onClick={() => handleDelete(component)}
                        >
                          Delete
                        </Button>
                      </Box>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} align="center">No salary components found</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Pagination Controls */}
        {totalPages > 1 && (
          <nav>
            <ul className="pagination justify-content-center">
              <li className={`page-item ${currentPage === 1 && 'disabled'}`}>
                <button className="page-link" onClick={() => setCurrentPage(currentPage - 1)}>Previous</button>
              </li>
              {Array.from({ length: totalPages }, (_, i) => (
                <li key={i} className={`page-item ${currentPage === i + 1 && 'active'}`}>
                  <button className="page-link" onClick={() => setCurrentPage(i + 1)}>{i + 1}</button>
                </li>
              ))}
              <li className={`page-item ${currentPage === totalPages && 'disabled'}`}>
                <button className="page-link" onClick={() => setCurrentPage(currentPage + 1)}>Next</button>
              </li>
            </ul>
          </nav>
        )}

        {/* Add/Edit Dialog Form */}
        <Dialog 
          open={showForm} 
          onClose={handleCloseForm}
          maxWidth="sm"
          fullWidth
        >
          <DialogTitle>{editingId ? 'Edit' : 'Add'} Salary Component</DialogTitle>
          <form onSubmit={handleSubmit}>
            <DialogContent>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <TextField
                  label="Name"
                  fullWidth
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />

                <FormControl fullWidth>
                  <InputLabel>Type</InputLabel>
                  <Select
                    value={formData.type}
                    label="Type"
                    onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  >
                    <MenuItem value="earning">Earning</MenuItem>
                    <MenuItem value="deduction">Deduction</MenuItem>
                  </Select>
                </FormControl>

                <TextField
                  label="Formula"
                  fullWidth
                  multiline
                  rows={2}
                  value={formData.formula}
                  onChange={(e) => setFormData({ ...formData, formula: e.target.value })}
                />

                <TextField
                  label="Description" 
                  fullWidth
                  multiline
                  rows={2}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                />
                <FormControlLabel
                  control={<Checkbox checked={formData.is_active} onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })} />}
                  label="Is Active"
                />
              </Box>
            </DialogContent>
            <DialogActions>
              <Button onClick={handleCloseForm}>Cancel</Button>
              <Button type="submit" variant="contained">
                {editingId ? 'Update' : 'Add'}
              </Button>
            </DialogActions>
          </form>
        </Dialog>

        {/* Snackbar for notifications */}
        <Snackbar
          open={toast.show}
          autoHideDuration={3000}
          onClose={() => setToast({ ...toast, show: false })}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        >
          <Alert 
            onClose={() => setToast({ ...toast, show: false })} 
            severity={toast.severity}
            sx={{ width: '100%' }}
          >
            {toast.message}
          </Alert>
        </Snackbar>
      </div>
    </PageLayout>
  );
}

export default SalaryComponents;
