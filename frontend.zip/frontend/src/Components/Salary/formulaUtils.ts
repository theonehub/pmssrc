import { evaluate } from 'mathjs';

export interface SalaryComponent {
  id: string;
  name: string;
  value: number;
  formula?: string;
}

export const evaluateFormula = (
  formula: string,
  components: Record<string, number>
): number => {
  try {
    return evaluate(formula, components);
  } catch (error) {
    console.error('Error evaluating formula:', error);
    return 0;
  }
};

export const validateFormula = (formula: string): boolean => {
  try {
    // Test with sample values
    const testValues = {
      Basic: 1000,
      HRA: 500,
      SpecialAllowance: 200,
    };
    evaluate(formula, testValues);
    return true;
  } catch (error) {
    return false;
  }
};

export const buildConditionalFormula = (
  condition: string,
  trueFormula: string,
  falseFormula: string = '0'
): string => {
  return `${condition} ? (${trueFormula}) : (${falseFormula})`;
};

export const formatFormula = (formula: string): string => {
  // Remove extra whitespace and normalize operators
  return formula
    .replace(/\s+/g, ' ')
    .replace(/\s*([+\-*/%()><=!])\s*/g, '$1')
    .trim();
}; 