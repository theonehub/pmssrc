import React, { useState, useCallback, useEffect } from 'react';
import ReactFlow, {
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  addEdge,
  Connection,
} from 'reactflow';
import 'reactflow/dist/style.css';
import {
  Box,
  Paper,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
} from '@mui/material';
import { Add as AddIcon, Save as SaveIcon } from '@mui/icons-material';
import axios from 'axios';
import SalaryComponentNode from '../components/salary/SalaryComponentNode';
import FormulaNode from '../components/salary/FormulaNode';
import { evaluateFormula, validateFormula } from '../components/salary/formulaUtils';

const nodeTypes = {
  salaryComponent: SalaryComponentNode,
  formula: FormulaNode,
};

const SalaryFormulaBuilder = () => {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [components, setComponents] = useState([]);
  const [isAddComponentOpen, setIsAddComponentOpen] = useState(false);
  const [newComponent, setNewComponent] = useState({ name: '', value: 0 });
  const [error, setError] = useState('');

  // Fetch existing salary components
  useEffect(() => {
    const fetchComponents = async () => {
      try {
        const response = await axios.get('/api/salary-components');
        setComponents(response.data);
      } catch (err) {
        setError('Failed to fetch salary components');
        console.error(err);
      }
    };
    fetchComponents();
  }, []);

  const onConnect = useCallback(
    (params: Connection) => {
      setEdges((eds) => addEdge(params, eds));
      // When connecting nodes, update the formula
      const sourceNode = nodes.find(n => n.id === params.source);
      const targetNode = nodes.find(n => n.id === params.target);
      if (sourceNode && targetNode && targetNode.type === 'formula') {
        // Update formula logic here
        const updatedNodes = nodes.map(node => {
          if (node.id === targetNode.id) {
            return {
              ...node,
              data: {
                ...node.data,
                sourceComponent: sourceNode.data.name
              }
            };
          }
          return node;
        });
        setNodes(updatedNodes);
      }
    },
    [nodes, setEdges, setNodes]
  );

  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();

      const type = event.dataTransfer.getData('application/reactflow');
      const name = event.dataTransfer.getData('name');

      if (!type) return;

      const position = {
        x: event.clientX - event.currentTarget.getBoundingClientRect().left,
        y: event.clientY - event.currentTarget.getBoundingClientRect().top,
      };

      const newNode = {
        id: Math.random().toString(),
        type,
        position,
        data: { name, value: 0 },
      };

      setNodes((nds) => nds.concat(newNode));
    },
    [setNodes]
  );

  const handleAddComponent = async () => {
    try {
      const response = await axios.post('/api/salary-components', newComponent);
      setComponents([...components, response.data]);
      setNewComponent({ name: '', value: 0 });
      setIsAddComponentOpen(false);
    } catch (err) {
      setError('Failed to add component');
      console.error(err);
    }
  };

  const handleSaveFormulas = async () => {
    try {
      const formulas = edges.map(edge => {
        const sourceNode = nodes.find(n => n.id === edge.source);
        const targetNode = nodes.find(n => n.id === edge.target);
        return {
          sourceComponent: sourceNode?.data.name,
          targetComponent: targetNode?.data.name,
          formula: targetNode?.data.formula,
        };
      });

      await axios.post('/api/salary-formulas', { formulas });
      // Show success message
    } catch (err) {
      setError('Failed to save formulas');
      console.error(err);
    }
  };

  return (
    <Box sx={{ height: 'calc(100vh - 100px)', display: 'flex', gap: 2, p: 2 }}>
      <Paper
        elevation={3}
        sx={{
          width: 250,
          p: 2,
          display: 'flex',
          flexDirection: 'column',
          gap: 2,
        }}
      >
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h6">Components</Typography>
          <Button
            size="small"
            startIcon={<AddIcon />}
            onClick={() => setIsAddComponentOpen(true)}
          >
            Add
          </Button>
        </Box>
        
        {components.map((component) => (
          <Paper
            key={component.id}
            draggable
            onDragStart={(event) => {
              event.dataTransfer.setData('application/reactflow', 'salaryComponent');
              event.dataTransfer.setData('name', component.name);
            }}
            sx={{
              p: 2,
              cursor: 'grab',
              '&:hover': { bgcolor: 'action.hover' },
            }}
          >
            <Typography>{component.name}</Typography>
          </Paper>
        ))}
      </Paper>

      <Paper elevation={3} sx={{ flexGrow: 1, position: 'relative' }}>
        <Box sx={{ position: 'absolute', top: 10, right: 10, zIndex: 1000 }}>
          <Button
            variant="contained"
            startIcon={<SaveIcon />}
            onClick={handleSaveFormulas}
          >
            Save Formulas
          </Button>
        </Box>
        
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          onDrop={onDrop}
          onDragOver={onDragOver}
          nodeTypes={nodeTypes}
          fitView
        >
          <Background />
          <Controls />
        </ReactFlow>
      </Paper>

      <Dialog open={isAddComponentOpen} onClose={() => setIsAddComponentOpen(false)}>
        <DialogTitle>Add Salary Component</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Component Name"
            fullWidth
            value={newComponent.name}
            onChange={(e) => setNewComponent({ ...newComponent, name: e.target.value })}
          />
          <TextField
            margin="dense"
            label="Default Value"
            type="number"
            fullWidth
            value={newComponent.value}
            onChange={(e) => setNewComponent({ ...newComponent, value: parseFloat(e.target.value) })}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setIsAddComponentOpen(false)}>Cancel</Button>
          <Button onClick={handleAddComponent} variant="contained">Add</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default SalaryFormulaBuilder; 